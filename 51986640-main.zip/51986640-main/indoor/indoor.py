hello = input().lower()
print(f"{hello}")