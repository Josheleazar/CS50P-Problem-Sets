play = input().replace(" ", "...")
print(f"{play}")