m = int(input("m: "))
c = 300000000
E = m*(c*c)
print(f"{E}")